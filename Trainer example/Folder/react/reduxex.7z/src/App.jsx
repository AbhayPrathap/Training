import React from 'react';

import './App.css';

class App extends React.Component {
  render() {
    return (
      <div className="App">
        Welcome to ToDO App
      </div>
    );
  }

}

export default App;
